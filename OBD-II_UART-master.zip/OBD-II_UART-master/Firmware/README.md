OBD-II UART Example Code
-------------------------

This Arduino sketch is designed to print out OBD data over a [Serial-Enabled LCD](https://www.sparkfun.com/products/9393) from an Arduino.

This sketch is written for Arduino 1.0+. 